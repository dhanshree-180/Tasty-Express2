import SectionHeading from "../components/SectionHeading";
import { brand } from "../data/menuData";
import "./InfoPage.css";

const seating = [
  "Indoor Air-conditioned Family Hall",
  "Cozy Booths for Couples",
  "Spacious Group Tables",
  "Private Party Room (on prior booking)",
];

export default function DineIn() {
  return (
    <>
      <section className="section info-hero">
        <div className="container">
          <SectionHeading
            eyebrow="Dine With Us"
            title="Experience delicious moments in our warm, cozy atmosphere"
            center
          />
        </div>
      </section>

      <section className="section">
        <div className="container info-grid">
          <div>
            <h3>🍽 A Place to Relax and Enjoy</h3>
            <p>
              Our dine-in space is designed for comfort, connection, and
              culinary delight. Whether you're on a date night, a family
              dinner, or a solo outing, you'll find the perfect seat waiting
              for you.
            </p>

            <h3>🪑 Seating Options</h3>
            <ul className="plain-list">
              {seating.map((s) => (
                <li key={s}>{s}</li>
              ))}
            </ul>
          </div>

          <div className="dine-card">
            <h3>🕒 Dine-In Hours</h3>
            <ul className="hours-list">
              {brand.hours.map((h) => (
                <li key={h.days}>
                  <span>{h.days}</span>
                  <strong>{h.time}</strong>
                </li>
              ))}
            </ul>

            <h3>📍 Location</h3>
            <p>{brand.name}, {brand.address} — easily accessible with ample parking.</p>

            <button type="button" className="btn btn-primary" style={{ width: "100%" }}>
              Book a Table
            </button>
          </div>
        </div>
      </section>
    </>
  );
}
