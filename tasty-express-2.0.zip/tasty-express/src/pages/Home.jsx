import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import Hero from "../components/Hero";
import SectionHeading from "../components/SectionHeading";
import MenuCard from "../components/MenuCard";
import Testimonials from "../components/Testimonials";
import { popularItems, categories } from "../data/menuData";
import { useLocalStorage } from "../hooks/useLocalStorage";
import { useReveal } from "../hooks/useReveal";
import "./Home.css";

export default function Home() {
  const [favorites, setFavorites] = useLocalStorage("tastyexpress:favorites", []);
  const [catRef, catInView] = useReveal();

  function toggleFavorite(id) {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    );
  }

  const displayCategories = categories.filter((c) => c !== "All");

  return (
    <>
      <Hero />

      <section className="section categories-section">
        <div className="container">
          <SectionHeading
            eyebrow="What are you craving?"
            title="Browse by category"
            center
          />
          <div
            ref={catRef}
            className={`category-grid reveal ${catInView ? "in-view" : ""}`}
          >
            {displayCategories.map((cat) => (
              <Link
                key={cat}
                to={`/menu?category=${encodeURIComponent(cat)}`}
                className="category-chip"
              >
                {cat}
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="section popular-section">
        <div className="container">
          <SectionHeading
            eyebrow="Fan favorites"
            title="Popular Signature Dishes"
            description="The five dishes our regulars order again and again."
          />
          <div className="menu-grid">
            {popularItems.map((item) => (
              <MenuCard
                key={item.id}
                item={item}
                favorite={favorites.includes(item.id)}
                onToggleFavorite={toggleFavorite}
              />
            ))}
          </div>
          <div className="popular-cta">
            <Link to="/menu" className="btn btn-outline">
              View Full Menu <ArrowRight size={17} />
            </Link>
          </div>
        </div>
      </section>

      <Testimonials />

      <section className="section cta-banner">
        <div className="container cta-banner-inner">
          <div>
            <h2>Hungry already?</h2>
            <p>Order online for pickup or delivery — ready in about 20 minutes.</p>
          </div>
          <Link to="/menu" className="btn btn-primary">
            Order Now
          </Link>
        </div>
      </section>
    </>
  );
}
