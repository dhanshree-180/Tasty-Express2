import SectionHeading from "../components/SectionHeading";
import "./InfoPage.css";

const values = [
  {
    icon: "💬",
    title: "Customer First",
    text: "Your satisfaction drives everything we do — from menu design to delivery speed.",
  },
  {
    icon: "🌱",
    title: "Fresh Always",
    text: "We use high-quality, locally sourced ingredients to keep our flavors natural and authentic.",
  },
  {
    icon: "⚡",
    title: "Express Service",
    text: "We believe great food shouldn't come slow. We're built to serve fast and hot.",
  },
];

export default function About() {
  return (
    <>
      <section className="section info-hero">
        <div className="container">
          <SectionHeading
            eyebrow="Who We Are"
            title="Delivering delicious moments — fast, fresh & full of flavor!"
            center
          />
        </div>
      </section>

      <section className="section">
        <div className="container info-grid">
          <div>
            <h3>Our Journey</h3>
            <p>
              Tasty Express was born from a simple idea: serve incredible food,
              fast. Starting in 2020, we've grown from a neighborhood kitchen to
              a beloved eatery known for our speedy service, fresh ingredients,
              and bold flavors.
            </p>
          </div>
          <div>
            <h3>What Makes Us Different</h3>
            <p>
              We mix culinary creativity with express delivery. Whether you're
              craving a cheesy burger, creamy pasta, or a classic Indian thali,
              every dish is made with care, served with love, and delivered
              with speed.
            </p>
          </div>
        </div>
      </section>

      <section className="section values-section">
        <div className="container">
          <SectionHeading eyebrow="Why choose us" title="Our Core Values" center />
          <div className="values-grid">
            {values.map((v) => (
              <div className="value-card" key={v.title}>
                <span className="value-icon" aria-hidden="true">{v.icon}</span>
                <h4>{v.title}</h4>
                <p>{v.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
