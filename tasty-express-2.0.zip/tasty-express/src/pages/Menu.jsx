import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Search, SearchX } from "lucide-react";
import MenuCard from "../components/MenuCard";
import SectionHeading from "../components/SectionHeading";
import { categories, menuItems } from "../data/menuData";
import { useLocalStorage } from "../hooks/useLocalStorage";
import "./Menu.css";

export default function Menu() {
  const [searchParams, setSearchParams] = useSearchParams();
  const activeCategory = searchParams.get("category") || "All";
  const [query, setQuery] = useState("");
  const [favorites, setFavorites] = useLocalStorage("tastyexpress:favorites", []);

  function toggleFavorite(id) {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    );
  }

  function setCategory(cat) {
    if (cat === "All") {
      searchParams.delete("category");
    } else {
      searchParams.set("category", cat);
    }
    setSearchParams(searchParams, { replace: true });
  }

  const filtered = useMemo(() => {
    return menuItems.filter((item) => {
      const matchesCategory =
        activeCategory === "All" || item.category === activeCategory;
      const matchesQuery = item.name
        .toLowerCase()
        .includes(query.trim().toLowerCase());
      return matchesCategory && matchesQuery;
    });
  }, [activeCategory, query]);

  return (
    <section className="section menu-page">
      <div className="container">
        <SectionHeading
          eyebrow="Full Menu"
          title="Explore our delicious and fresh fast-food offerings"
          center
        />

        <div className="menu-toolbar">
          <div className="search-box">
            <Search size={18} />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search dishes..."
              aria-label="Search the menu"
            />
          </div>
          <div className="category-tabs" role="tablist" aria-label="Menu categories">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                role="tab"
                aria-selected={activeCategory === cat}
                className={`category-tab ${activeCategory === cat ? "is-active" : ""}`}
                onClick={() => setCategory(cat)}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="menu-empty">
            <SearchX size={40} strokeWidth={1.3} />
            <h3>No dishes found</h3>
            <p>Try a different search term or category.</p>
          </div>
        ) : (
          <div className="menu-grid">
            {filtered.map((item) => (
              <MenuCard
                key={item.id}
                item={item}
                favorite={favorites.includes(item.id)}
                onToggleFavorite={toggleFavorite}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
