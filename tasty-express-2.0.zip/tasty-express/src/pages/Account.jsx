import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "../context/ToastContext";
import "./Account.css";

export default function Account() {
  const [mode, setMode] = useState("login");
  const { showToast } = useToast();
  const navigate = useNavigate();

  function handleSubmit(e) {
    e.preventDefault();
    showToast(mode === "login" ? "Logged in! (demo only)" : "Account created! (demo only)");
    navigate("/");
  }

  return (
    <section className="section account-section">
      <div className="container account-container">
        <div className="account-card">
          <div className="account-tabs">
            <button
              type="button"
              className={mode === "login" ? "is-active" : ""}
              onClick={() => setMode("login")}
            >
              Login
            </button>
            <button
              type="button"
              className={mode === "signup" ? "is-active" : ""}
              onClick={() => setMode("signup")}
            >
              Sign Up
            </button>
          </div>

          <form onSubmit={handleSubmit} className="account-form">
            {mode === "signup" && (
              <label>
                Full name
                <input type="text" required placeholder="Your name" />
              </label>
            )}
            <label>
              Email
              <input type="email" required placeholder="you@example.com" />
            </label>
            <label>
              Password
              <input type="password" required placeholder="••••••••" minLength={6} />
            </label>

            <button type="submit" className="btn btn-primary">
              {mode === "login" ? "Login" : "Sign Up"}
            </button>
          </form>

          <p className="account-switch">
            {mode === "login" ? (
              <>Don't have an account? <button type="button" onClick={() => setMode("signup")}>Sign Up</button></>
            ) : (
              <>Already have an account? <button type="button" onClick={() => setMode("login")}>Login</button></>
            )}
          </p>
        </div>
      </div>
    </section>
  );
}
