import { useState } from "react";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import SectionHeading from "../components/SectionHeading";
import { brand } from "../data/menuData";
import { useToast } from "../context/ToastContext";
import "./InfoPage.css";

export default function Contact() {
  const { showToast } = useToast();
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });

  function handleChange(e) {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
  }

  function handleSubmit(e) {
    e.preventDefault();
    showToast(`Thanks ${form.name.split(" ")[0] || "there"}, we'll get back to you soon!`);
    setForm({ name: "", email: "", phone: "", message: "" });
  }

  return (
    <>
      <section className="section info-hero">
        <div className="container">
          <SectionHeading
            eyebrow="Get in touch"
            title="We'd love to hear from you"
            center
          />
        </div>
      </section>

      <section className="section">
        <div className="container contact-grid">
          <div className="contact-details">
            <div className="contact-item">
              <MapPin size={20} />
              <div>
                <h4>Address</h4>
                <p>{brand.name}, {brand.address}</p>
              </div>
            </div>
            <div className="contact-item">
              <Phone size={20} />
              <div>
                <h4>Phone</h4>
                <p>{brand.phone}</p>
              </div>
            </div>
            <div className="contact-item">
              <Mail size={20} />
              <div>
                <h4>Email</h4>
                <p>{brand.email}</p>
              </div>
            </div>
            <div className="contact-item">
              <Clock size={20} />
              <div>
                <h4>Hours</h4>
                {brand.hours.map((h) => (
                  <p key={h.days}>{h.days}: {h.time}</p>
                ))}
              </div>
            </div>
          </div>

          <form className="contact-form" onSubmit={handleSubmit}>
            <label>
              Name
              <input
                type="text"
                name="name"
                value={form.name}
                onChange={handleChange}
                required
              />
            </label>
            <label>
              Email
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                required
              />
            </label>
            <label>
              Phone (optional)
              <input type="tel" name="phone" value={form.phone} onChange={handleChange} />
            </label>
            <label>
              Message
              <textarea
                name="message"
                rows="4"
                value={form.message}
                onChange={handleChange}
                required
              />
            </label>
            <button type="submit" className="btn btn-primary">Send Message</button>
          </form>
        </div>
      </section>
    </>
  );
}
