// Menu content preserved from the original Tasty Express site.
// Image URLs point at the original site's asset files so existing
// imagery is kept; swap these for licensed photography when ready
// (see README for notes on the current placeholder images).
const IMG_BASE =
  "https://raw.githubusercontent.com/dhanshree-11/TastyExpress_1/main/";

export const categories = [
  "All",
  "Burgers & Wraps",
  "Pizza",
  "Fries & Sides",
  "Drinks & Shakes",
  "Desserts",
];

export const menuItems = [
  // Burgers & Wraps
  {
    id: "veg-supreme-burger",
    name: "Veg Supreme Burger",
    description: "Loaded with veggies, cheese & tangy mayo.",
    price: 99,
    category: "Burgers & Wraps",
    veg: true,
    popular: false,
    image: IMG_BASE + "juicy-burger-with-crispy-fries-red-onions.png",
  },
  {
    id: "spicy-paneer-wrap",
    name: "Spicy Paneer Wrap",
    description: "Paneer tikka, lettuce, sauces in a wrap.",
    price: 109,
    category: "Burgers & Wraps",
    veg: true,
    popular: true,
    image: IMG_BASE + "Screenshot 2025-07-08 142705.png",
  },
  {
    id: "grilled-chicken-wrap",
    name: "Grilled Chicken Wrap",
    description: "Marinated chicken strips with veggies and aioli.",
    price: 129,
    category: "Burgers & Wraps",
    veg: false,
    popular: false,
    image:
      IMG_BASE +
      "side-view-chicken-roll-fried-chicken-strips-with-mayo-tomato-lettuce-wrapped-tortilla.jpg",
  },
  {
    id: "cheese-burst-burger",
    name: "Cheese Burst Burger",
    description: "Stuffed with double cheese and crispy patty.",
    price: 119,
    category: "Burgers & Wraps",
    veg: true,
    popular: false,
    image: IMG_BASE + "still-life-delicious-american-hamburger.jpg",
  },

  // Pizza — added to fix the homepage/menu mismatch: "Veggie Loaded Pizza"
  // was featured on the homepage but missing from the menu. Price is an
  // estimate (₹149) since the original site never listed one — adjust freely.
  {
    id: "veggie-loaded-pizza",
    name: "Veggie Loaded Pizza",
    description: "Wood-fired base topped with fresh veggies and mozzarella.",
    price: 149,
    priceIsEstimate: true,
    category: "Pizza",
    veg: true,
    popular: true,
    image: IMG_BASE + "Screenshot 2025-07-08 142851.png",
  },

  // Fries & Sides
  {
    id: "masala-fries",
    name: "Masala Fries",
    description: "Crispy fries tossed in spicy Indian masala.",
    price: 69,
    category: "Fries & Sides",
    veg: true,
    popular: true,
    image: IMG_BASE + "Screenshot 2025-07-08 143219.png",
  },
  {
    id: "cheesy-fries",
    name: "Cheesy Fries",
    description: "Golden fries drizzled with hot cheese sauce.",
    price: 79,
    category: "Fries & Sides",
    veg: true,
    popular: false,
    image: IMG_BASE + "view-delicious-poutine.jpg",
  },
  {
    id: "loaded-nachos",
    name: "Loaded Nachos",
    description: "Corn chips topped with cheese, beans & salsa.",
    price: 99,
    category: "Fries & Sides",
    veg: true,
    popular: false,
    image:
      IMG_BASE + "freshly-grilled-beef-vegetable-taco-plate-generative-ai.jpg",
  },
  {
    id: "cheesy-garlic-bread",
    name: "Cheesy Garlic Bread",
    description: "Toasted bread loaded with garlic butter & cheese.",
    price: 89,
    category: "Fries & Sides",
    veg: true,
    popular: false,
    image:
      IMG_BASE +
      "closeup-italian-appetizer-bruschettas-with-tomato-sauce-parmesan-cheese-wooden-table-h.jpg",
  },

  // Drinks & Shakes
  {
    id: "chocolate-blast-shake",
    name: "Chocolate Blast Shake",
    description: "Rich chocolate shake with brownie chunks.",
    price: 99,
    category: "Drinks & Shakes",
    veg: true,
    popular: true,
    image: IMG_BASE + "Screenshot 2025-07-08 143053.png",
  },
  {
    id: "strawberry-cream-shake",
    name: "Strawberry Cream Shake",
    description: "Fresh strawberry puree & vanilla cream blend.",
    price: 89,
    category: "Drinks & Shakes",
    veg: true,
    popular: false,
    image: IMG_BASE + "strawberry-milkshake-with-ice-table.jpg",
  },
  {
    id: "oreo-milkshake",
    name: "Oreo Milkshake",
    description: "Blended Oreos with milk & creamy delight.",
    price: 99,
    category: "Drinks & Shakes",
    veg: true,
    popular: false,
    image: IMG_BASE + "front-view-dessert-jar-with-chocolate-biscuits-rolls.jpg",
  },
  {
    id: "mint-lemonade",
    name: "Mint Lemonade",
    description: "Refreshing lemon drink with mint leaves.",
    price: 59,
    category: "Drinks & Shakes",
    veg: true,
    popular: false,
    image: IMG_BASE + "lemonade-with-lemon-mint-ice-cubes.jpg",
  },

  // Desserts
  {
    id: "mango-mania-sundae",
    name: "Mango Mania Sundae",
    description: "Vanilla ice cream with fresh mango pulp.",
    price: 89,
    category: "Desserts",
    veg: true,
    popular: true,
    image: IMG_BASE + "Screenshot 2025-07-08 143336.png",
  },
  {
    id: "choco-fudge-brownie",
    name: "Choco Fudge Brownie",
    description: "Warm brownie with chocolate drizzle.",
    price: 79,
    category: "Desserts",
    veg: true,
    popular: false,
    image: IMG_BASE + "front-view-delicious-chocolate-cake-with-almonds.jpg",
  },
  {
    id: "mini-gulab-jamun",
    name: "Mini Gulab Jamun",
    description: "Classic Indian sweet with cardamom syrup.",
    price: 49,
    category: "Desserts",
    veg: true,
    popular: false,
    image: IMG_BASE + "Screenshot 2025-07-08 155649.png",
  },
];

export const popularItems = menuItems.filter((item) => item.popular);

export const testimonials = [
  {
    name: "Aditi R.",
    rating: 5,
    quote:
      "Absolutely love the paneer wrap! It's spicy, fresh, and fills me up every time.",
  },
  {
    name: "Neeraj T.",
    rating: 4,
    quote: "Their chocolate blast shake is heaven. Super thick and chocolaty!",
  },
  {
    name: "Shruti M.",
    rating: 5,
    quote: "Great service and lovely atmosphere. Fries are crispy and flavorful!",
  },
];

export const brand = {
  name: "Tasty Express",
  tagline: "Your Hunger, Our Express Mission!",
  logo: IMG_BASE + "Screenshot 2025-05-11 135557.png",
  phone: "8261077665",
  email: "contact@tastyexpress.com",
  address: "Vasudev Nagar, Nagpur",
  hours: [
    { days: "Monday – Friday", time: "11:00 AM – 10:00 PM" },
    { days: "Saturday – Sunday", time: "10:00 AM – 11:00 PM" },
  ],
};
