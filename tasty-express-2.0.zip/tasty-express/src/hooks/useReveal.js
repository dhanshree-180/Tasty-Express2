import { useEffect, useRef, useState } from "react";

// Adds an "in-view" class the first time an element scrolls into the
// viewport, used together with the .reveal CSS class for a single,
// restrained fade-and-slide entrance (see frontend design notes).
export function useReveal(threshold = 0.15) {
  const ref = useRef(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          observer.disconnect();
        }
      },
      { threshold }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [threshold]);

  return [ref, inView];
}
