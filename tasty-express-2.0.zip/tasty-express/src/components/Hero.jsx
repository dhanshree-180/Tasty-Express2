import { Link } from "react-router-dom";
import { Star, Timer } from "lucide-react";
import { menuItems, brand } from "../data/menuData";
import "./Hero.css";

const heroDish = menuItems.find((i) => i.id === "cheese-burst-burger");

export default function Hero() {
  return (
    <section className="hero">
      <div className="container hero-inner">
        <div className="hero-copy">
          <span className="eyebrow">
            <span className="speed-divider"><span></span><span></span><span></span></span>
            Fast-casual, Nagpur
          </span>
          <h1>{brand.name}</h1>
          <p className="hero-tagline">{brand.tagline}</p>
          <p className="hero-sub">
            Bold, fresh, fast-casual food made to order — from loaded burgers
            to spicy wraps, crispy sides and shakes worth the drive.
          </p>
          <div className="hero-actions">
            <Link to="/menu" className="btn btn-primary">
              Order Now
            </Link>
            <Link to="/dine-in" className="btn btn-outline">
              Reserve a Table
            </Link>
          </div>
          <div className="hero-stats">
            <div>
              <Star size={18} fill="currentColor" />
              <div>
                <strong>4.8/5</strong>
                <span>Customer rating</span>
              </div>
            </div>
            <div>
              <Timer size={18} />
              <div>
                <strong>~20 min</strong>
                <span>Average delivery</span>
              </div>
            </div>
          </div>
        </div>

        <div className="hero-visual">
          <div className="hero-blob" aria-hidden="true"></div>
          <img src={heroDish.image} alt={heroDish.name} className="hero-image" />
          <div className="hero-tag">
            <span>Bestseller</span>
            <strong>{heroDish.name}</strong>
            <em>₹{heroDish.price}</em>
          </div>
        </div>
      </div>
    </section>
  );
}
