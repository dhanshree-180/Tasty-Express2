import { X, Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { useCart } from "../context/CartContext";
import "./CartDrawer.css";

export default function CartDrawer({ open, onClose }) {
  const { items, updateQty, removeItem, clearCart, subtotal } = useCart();

  const deliveryFee = items.length > 0 ? 25 : 0;
  const total = subtotal + deliveryFee;

  return (
    <>
      <div
        className={`cart-overlay ${open ? "is-open" : ""}`}
        onClick={onClose}
        aria-hidden="true"
      />
      <aside
        className={`cart-drawer ${open ? "is-open" : ""}`}
        aria-hidden={!open}
        aria-label="Shopping cart"
      >
        <div className="cart-drawer-head">
          <h3>Your Order</h3>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Close cart">
            <X size={22} />
          </button>
        </div>

        {items.length === 0 ? (
          <div className="cart-empty">
            <ShoppingBag size={40} strokeWidth={1.3} />
            <p>Your cart is empty. Add something tasty!</p>
            <button type="button" className="btn btn-primary" onClick={onClose}>
              Browse Menu
            </button>
          </div>
        ) : (
          <>
            <ul className="cart-list">
              {items.map((item) => (
                <li key={item.id} className="cart-item">
                  <img src={item.image} alt="" />
                  <div className="cart-item-info">
                    <p className="cart-item-name">{item.name}</p>
                    <p className="cart-item-price">₹{item.price}</p>
                    <div className="qty-control">
                      <button
                        type="button"
                        aria-label={`Decrease quantity of ${item.name}`}
                        onClick={() => updateQty(item.id, item.qty - 1)}
                      >
                        <Minus size={14} />
                      </button>
                      <span>{item.qty}</span>
                      <button
                        type="button"
                        aria-label={`Increase quantity of ${item.name}`}
                        onClick={() => updateQty(item.id, item.qty + 1)}
                      >
                        <Plus size={14} />
                      </button>
                    </div>
                  </div>
                  <button
                    type="button"
                    className="cart-item-remove"
                    aria-label={`Remove ${item.name} from cart`}
                    onClick={() => removeItem(item.id)}
                  >
                    <Trash2 size={17} />
                  </button>
                </li>
              ))}
            </ul>

            <div className="cart-summary">
              <div className="cart-summary-row">
                <span>Subtotal</span>
                <span>₹{subtotal}</span>
              </div>
              <div className="cart-summary-row">
                <span>Delivery fee</span>
                <span>₹{deliveryFee}</span>
              </div>
              <div className="cart-summary-row cart-summary-total">
                <span>Total</span>
                <span>₹{total}</span>
              </div>
              <button type="button" className="btn btn-primary cart-checkout">
                Proceed to Checkout
              </button>
              <button type="button" className="cart-clear" onClick={clearCart}>
                Clear cart
              </button>
            </div>
          </>
        )}
      </aside>
    </>
  );
}
