import { useState } from "react";
import { NavLink } from "react-router-dom";
import { Menu, X, ShoppingBag, UserCircle } from "lucide-react";
import { brand } from "../data/menuData";
import { useCart } from "../context/CartContext";
import "./Navbar.css";

const LINKS = [
  { to: "/", label: "Home" },
  { to: "/menu", label: "Menu" },
  { to: "/dine-in", label: "Dine In" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

export default function Navbar({ onOpenCart }) {
  const [open, setOpen] = useState(false);
  const { itemCount } = useCart();

  return (
    <header className="navbar">
      <div className="container navbar-inner">
        <NavLink to="/" className="navbar-brand" onClick={() => setOpen(false)}>
          <img src={brand.logo} alt="" aria-hidden="true" />
          <span>{brand.name}</span>
        </NavLink>

        <nav className={`navbar-links ${open ? "is-open" : ""}`}>
          {LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.to === "/"}
              className={({ isActive }) =>
                "navbar-link" + (isActive ? " is-active" : "")
              }
              onClick={() => setOpen(false)}
            >
              {link.label}
            </NavLink>
          ))}
          <NavLink
            to="/account"
            className="navbar-link navbar-link-mobile-only"
            onClick={() => setOpen(false)}
          >
            Sign In
          </NavLink>
        </nav>

        <div className="navbar-actions">
          <NavLink to="/account" className="icon-btn" aria-label="Sign in or sign up">
            <UserCircle size={22} strokeWidth={1.8} />
          </NavLink>
          <button
            type="button"
            className="icon-btn cart-btn"
            aria-label={`Open cart, ${itemCount} item${itemCount === 1 ? "" : "s"}`}
            onClick={onOpenCart}
          >
            <ShoppingBag size={22} strokeWidth={1.8} />
            {itemCount > 0 && <span className="cart-badge">{itemCount}</span>}
          </button>
          <button
            type="button"
            className="icon-btn menu-toggle"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
    </header>
  );
}
