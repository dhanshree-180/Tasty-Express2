import { Heart, Plus, Leaf } from "lucide-react";
import { useCart } from "../context/CartContext";
import "./MenuCard.css";

export default function MenuCard({ item, favorite, onToggleFavorite }) {
  const { addItem } = useCart();

  return (
    <article className="menu-card">
      <div className="menu-card-media">
        <img src={item.image} alt={item.name} loading="lazy" />
        {item.veg && (
          <span className="veg-badge" aria-label="Vegetarian">
            <Leaf size={12} />
          </span>
        )}
        <button
          type="button"
          className={`fav-btn ${favorite ? "is-fav" : ""}`}
          aria-label={favorite ? `Remove ${item.name} from favorites` : `Add ${item.name} to favorites`}
          aria-pressed={favorite}
          onClick={() => onToggleFavorite(item.id)}
        >
          <Heart size={17} fill={favorite ? "currentColor" : "none"} />
        </button>
      </div>

      <div className="menu-card-body">
        <h4>{item.name}</h4>
        <p>{item.description}</p>
        <div className="menu-card-footer">
          <span className="menu-card-price">
            ₹{item.price}
            {item.priceIsEstimate && <sup title="Estimated price">*</sup>}
          </span>
          <button
            type="button"
            className="add-btn"
            onClick={() => addItem(item)}
            aria-label={`Add ${item.name} to cart`}
          >
            <Plus size={16} strokeWidth={2.4} />
            Add
          </button>
        </div>
      </div>
    </article>
  );
}
