import { Star } from "lucide-react";
import { testimonials } from "../data/menuData";
import SectionHeading from "./SectionHeading";
import { useReveal } from "../hooks/useReveal";
import "./Testimonials.css";

function Card({ t, index }) {
  const [ref, inView] = useReveal();
  return (
    <blockquote
      ref={ref}
      className={`testimonial-card reveal ${inView ? "in-view" : ""}`}
      style={{ transitionDelay: `${index * 90}ms` }}
    >
      <div className="stars" aria-hidden="true">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            size={16}
            fill={i < t.rating ? "currentColor" : "none"}
          />
        ))}
      </div>
      <p>&ldquo;{t.quote}&rdquo;</p>
      <cite>{t.name}</cite>
    </blockquote>
  );
}

export default function Testimonials() {
  return (
    <section className="section testimonials">
      <div className="container">
        <SectionHeading
          eyebrow="What our customers say"
          title="Loved by regulars across Nagpur"
          center
        />
        <div className="testimonial-grid">
          {testimonials.map((t, i) => (
            <Card t={t} key={t.name} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
