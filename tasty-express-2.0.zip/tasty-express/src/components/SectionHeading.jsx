export default function SectionHeading({ eyebrow, title, description, center }) {
  return (
    <div className={`section-head ${center ? "center" : ""}`}>
      {eyebrow && (
        <span className="eyebrow">
          <span className="speed-divider">
            <span></span><span></span><span></span>
          </span>
          {eyebrow}
        </span>
      )}
      <h2>{title}</h2>
      {description && <p>{description}</p>}
    </div>
  );
}
