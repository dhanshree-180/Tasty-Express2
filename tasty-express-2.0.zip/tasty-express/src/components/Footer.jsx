import { NavLink } from "react-router-dom";
import { MapPin, Phone, Mail } from "lucide-react";
import { brand } from "../data/menuData";
import "./Footer.css";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <div className="footer-brand">
          <div className="navbar-brand">
            <img src={brand.logo} alt="" aria-hidden="true" />
            <span>{brand.name}</span>
          </div>
          <p>Serving joy, one dish at a time. Visit us for a delightful dine-in or quick takeaway experience!</p>
        </div>

        <div className="footer-col">
          <h4>Quick Links</h4>
          <NavLink to="/">Home</NavLink>
          <NavLink to="/menu">Menu</NavLink>
          <NavLink to="/dine-in">Dine In</NavLink>
          <NavLink to="/about">About</NavLink>
          <NavLink to="/contact">Contact</NavLink>
        </div>

        <div className="footer-col">
          <h4>Contact Us</h4>
          <p className="footer-line"><MapPin size={16} /> {brand.address}</p>
          <p className="footer-line"><Phone size={16} /> {brand.phone}</p>
          <p className="footer-line"><Mail size={16} /> {brand.email}</p>
        </div>
      </div>
      <div className="footer-bottom">
        <div className="container">
          © {new Date().getFullYear()} {brand.name}. All Rights Reserved.
        </div>
      </div>
    </footer>
  );
}
